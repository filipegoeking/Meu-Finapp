
import React,{useMemo,useState} from 'react'
import {createRoot} from 'react-dom/client'
import './styles.css'

const initialTx=[
{id:1,date:'2026-09-10',description:'Salário',type:'Receita',account:'Conta Corrente',category:'Salário',group:'Entrada',value:9901.50},
{id:2,date:'2026-09-02',description:'Mercado',type:'Despesa',account:'Conta Corrente',category:'Mercado',group:'P1 Sustentação',value:450},
{id:3,date:'2026-09-05',description:'Restaurante',type:'Despesa',account:'Cartão Principal',category:'Comer Fora',group:'P4 Opcionais',value:180},
{id:4,date:'2026-09-08',description:'Compra parcelada',type:'Despesa',account:'Cartão Principal',category:'Parcelamento',group:'P5 Quitações',value:1200,installments:12}
]
const budgets=[
{category:'Mercado',group:'P1 Sustentação',budget:1300,elastic:'Otimizável'},
{category:'Combustível',group:'P1 Sustentação',budget:350,elastic:'Otimizável'},
{category:'Farmácia',group:'P1 Sustentação',budget:200,elastic:'Otimizável'},
{category:'Comer Fora',group:'P4 Opcionais',budget:200,elastic:'Discricionário'},
{category:'Streaming',group:'P4 Opcionais',budget:100,elastic:'Discricionário'},
{category:'Reserva',group:'P3 Propósito',budget:1000,elastic:'Essencial Reserva'}
]
const nav=[['dashboard','Dashboard'],['lancamentos','Lançamentos'],['contas','Contas'],['cartoes','Cartões'],['parcelas','Parcelas'],['orcamento','Orçamento'],['metas','Metas'],['projecao','Projeção'],['simulador','Simulador'],['analista','Analista IA'],['config','Configurações']]
const money=n=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})
const titles={dashboard:['Visão geral','Presente, futuro e decisões financeiras em um só lugar.'],lancamentos:['Lançamentos','Registre e organize as movimentações.'],contas:['Contas','Saldos e movimentações por conta.'],cartoes:['Cartões','Limites, faturas e comprometimentos.'],parcelas:['Parcelas','Obrigações que continuam impactando o futuro.'],orcamento:['Orçamento','Planejado, realizado e restante.'],metas:['Metas','Dinheiro direcionado para propósitos.'],projecao:['Projeção','Visão dos próximos meses.'],simulador:['Simulador','Teste o impacto de uma compra antes de realizá-la.'],analista:['Analista Financeiro','Converse com os dados financeiros do produto.'],config:['Configurações','Parâmetros, regras e documentação do sistema.']}

function App(){
 const [view,setView]=useState('dashboard')
 const [tx,setTx]=useState(initialTx)
 const [question,setQuestion]=useState('')
 const [messages,setMessages]=useState([])
 const [help,setHelp]=useState(null)
 const [params,setParams]=useState({
   averageMonths:3, projectionMonths:12, minimumBalance:2000, budgetTolerance:10,
   showProjected:true, includeFuture:true
 })
 const parameterHelp={
   averageMonths:{title:'Meses para cálculo da média',desc:'Define quantos meses históricos entram no cálculo da média de uma categoria.',example:'Com 3 meses, o sistema considera os últimos 3 meses registrados.',impact:'Influencia médias, projeções, alertas e sugestões do Analista Financeiro.'},
   projectionMonths:{title:'Horizonte da projeção',desc:'Define quantos meses serão exibidos no planejamento futuro.',example:'12 meses mostra o período do mês atual até os próximos 11 meses.',impact:'Influencia a tela de Projeção e análises prospectivas.'},
   minimumBalance:{title:'Saldo mínimo desejado',desc:'Valor de referência para acompanhar uma reserva mínima de caixa.',example:'R$ 2.000 indica que valores abaixo desse nível podem gerar alerta.',impact:'Pode alimentar alertas e leituras do Analista Financeiro.'},
   budgetTolerance:{title:'Tolerância do orçamento',desc:'Percentual de variação aceito antes de considerar que uma categoria merece atenção.',example:'10% permite ultrapassar o orçamento em até 10% antes de um alerta.',impact:'Influencia alertas e sinalizações do orçamento.'},
   showProjected:{title:'Mostrar valores projetados',desc:'Controla a exibição de valores estimados junto às informações futuras.',example:'Desligado deixa a interface mais conservadora, mostrando somente o realizado.',impact:'Afeta Dashboard, Projeção e análises futuras.'},
   includeFuture:{title:'Considerar lançamentos futuros',desc:'Define se parcelas e recorrências conhecidas entram nos cálculos prospectivos.',example:'Ligado permite visualizar compromissos já conhecidos nos próximos meses.',impact:'Afeta Projeção, compromissos e análises do Analista Financeiro.'}
 }
 const [sim,setSim]=useState({value:8000,down:2000,n:12,rate:1.5})
 const income=useMemo(()=>tx.filter(t=>t.type==='Receita').reduce((s,t)=>s+t.value,0),[tx])
 const expense=useMemo(()=>tx.filter(t=>t.type==='Despesa').reduce((s,t)=>s+t.value,0),[tx])
 const future=useMemo(()=>tx.filter(t=>t.installments).reduce((s,t)=>s+t.value*(t.installments-1)/t.installments,0),[tx])
 const balance=income-expense
 const spent=c=>tx.filter(t=>t.type==='Despesa'&&t.category===c).reduce((s,t)=>s+t.value,0)

 function add(e){
   e.preventDefault();const f=new FormData(e.currentTarget)
   const item={id:Date.now(),date:f.get('date'),description:f.get('description'),type:f.get('type'),account:f.get('account'),category:f.get('category'),group:f.get('group'),value:Number(f.get('value')),installments:Number(f.get('installments'))||undefined}
   if(!item.description||!item.value)return
   setTx(x=>[...x,item]);e.currentTarget.reset()
 }
 function ask(){
   const q=question.trim();if(!q)return
   let a
   if(/gastei|despesas|gasto/i.test(q))a=`As despesas registradas somam ${money(expense)}.`
   else if(/comprom|parcel/i.test(q))a=`Os compromissos futuros identificados somam ${money(future)}.`
   else if(/saldo|sobrou/i.test(q))a=`O saldo entre receitas e despesas registradas é ${money(balance)}.`
   else if(/receita|sal[aá]rio|entrada/i.test(q))a=`As receitas registradas somam ${money(income)}.`
   else if(/mercado|or[cç]amento/i.test(q))a=`O orçamento de mercado é ${money(1300)} e o realizado é ${money(spent('Mercado'))}.`
   else a='Consigo consultar receitas, despesas, saldo, orçamento e compromissos com os dados registrados nesta V1.'
   setMessages(m=>[...m,{who:'user',text:q},{who:'assistant',text:a}]);setQuestion('')
 }
 const loan=()=>{const v=Math.max(sim.value-sim.down,0),r=sim.rate/100,n=sim.n,p=r?v*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1):v/n;return {v,p,total:p*n+sim.down}}
 const simr=loan()
 return <div className="app">
  <aside className="sidebar"><div className="logo">Finanças Pessoais<small>V1 — núcleo financeiro</small></div><nav className="nav">{nav.map(([id,label])=><button key={id} className={view===id?'active':''} onClick={()=>setView(id)}>{label}</button>)}</nav></aside>
  <main className="content">
   <header className="top"><div><h1>{titles[view][0]}</h1><p>{titles[view][1]}</p></div><button className="btn primary" onClick={()=>setView('lancamentos')}>+ Novo lançamento</button></header>

   {view==='dashboard'&&<div className="view active">
    <div className="cards">{[['Receitas',income,'Entradas'],['Despesas',expense,'Realizado'],['Compromissos futuros',future,'Parcelas abertas'],['Saldo',balance,'Receitas − despesas']].map(x=><div className="card" key={x[0]}><div className="label">{x[0]}</div><div className="money">{money(x[1])}</div><div className="muted">{x[2]}</div></div>)}</div>
    <div className="grid"><div className="panel"><h2>Orçamento por categoria</h2>{budgets.map(b=>{const s=spent(b.category),p=Math.min(s/b.budget*100,100);return <div key={b.category} className="row"><div><b>{b.category}</b><div className="muted">{b.group} · {b.elastic}</div><div className="bar"><i style={{width:p+'%'}}/></div></div><b>{money(s)} / {money(b.budget)}</b></div>})}</div>
    <div className="panel"><h2>Leitura rápida</h2><div className="row"><span>Saldo do mês</span><b className={balance>=0?'green':'red'}>{money(balance)}</b></div><div className="row"><span>Parcelas futuras</span><b>{money(future)}</b></div><div className="row"><span>Compras registradas</span><b>{tx.length}</b></div><div className="row"><span>Último compromisso</span><b>{tx.some(t=>t.installments)?'12 parcelas':'—'}</b></div></div></div>
   </div>}

   {view==='lancamentos'&&<div className="view active"><div className="panel"><h2>Novo lançamento</h2><form onSubmit={add}><div className="form">
    <div className="field"><label>Descrição</label><input name="description"/></div><div className="field"><label>Data</label><input name="date" type="date" defaultValue="2026-09-23"/></div>
    <div className="field"><label>Tipo</label><select name="type"><option>Despesa</option><option>Receita</option><option>Transferência</option></select></div><div className="field"><label>Valor</label><input name="value" type="number" step="0.01"/></div>
    <div className="field"><label>Conta / cartão</label><select name="account"><option>Conta Corrente</option><option>Cartão Principal</option><option>Swile</option></select></div>
    <div className="field"><label>Categoria</label><select name="category"><option>Mercado</option><option>Combustível</option><option>Farmácia</option><option>Comer Fora</option><option>Streaming</option><option>Salário</option><option>Reserva</option><option>Parcelamento</option></select></div>
    <div className="field"><label>Grupo</label><select name="group"><option>P1 Sustentação</option><option>P2 Previsíveis</option><option>P3 Propósito</option><option>P4 Opcionais</option><option>P5 Quitações</option><option>Fluxo de Repasse</option></select></div>
    <div className="field"><label>Nº parcelas</label><input name="installments" type="number" min="1" placeholder="1"/></div></div><div className="form-actions"><button className="btn primary">Adicionar</button></div></form></div>
    <div className="panel" style={{marginTop:16}}><h2>Histórico</h2><table><thead><tr><th>Data</th><th>Descrição</th><th>Grupo</th><th>Categoria</th><th>Conta</th><th>Valor</th></tr></thead><tbody>{tx.map(t=><tr key={t.id}><td>{new Date(t.date+'T12:00:00').toLocaleDateString('pt-BR')}</td><td>{t.description}</td><td><span className="tag">{t.group}</span></td><td>{t.category}</td><td>{t.account}</td><td>{money(t.value)}</td></tr>)}</tbody></table></div></div>}

   {view==='contas'&&<div className="view active"><div className="panel"><h2>Contas</h2>{['Conta Corrente','Poupança','Swile'].map(a=>{const d=tx.filter(t=>t.account===a).reduce((s,t)=>s+(t.type==='Receita'?t.value:t.type==='Despesa'?-t.value:0),0);return <div className="row" key={a}><span><b>{a}</b><div className="muted">{a==='Swile'?'VR/VA':'Conta financeira'}</div></span><b>{money(d)}</b></div>})}</div></div>}

   {view==='cartoes'&&<div className="view active"><div className="panel"><h2>Cartões</h2><table><thead><tr><th>Cartão</th><th>Limite</th><th>Compras</th><th>Disponível</th><th>Fechamento</th><th>Vencimento</th></tr></thead><tbody><tr><td>Cartão Principal</td><td>{money(10000)}</td><td>{money(tx.filter(t=>t.account==='Cartão Principal'&&t.type==='Despesa').reduce((s,t)=>s+t.value,0))}</td><td>{money(9820)}</td><td>Dia 10</td><td>Dia 17</td></tr><tr><td>Cartão 2</td><td>{money(5000)}</td><td>{money(0)}</td><td>{money(5000)}</td><td>Dia 20</td><td>Dia 27</td></tr></tbody></table></div></div>}

   {view==='parcelas'&&<div className="view active"><div className="panel"><h2>Compromissos futuros</h2><table><thead><tr><th>Compra</th><th>Total</th><th>Parcelas</th><th>Parcela</th><th>Futuro</th><th>Última parcela</th></tr></thead><tbody>{tx.filter(t=>t.installments).map(t=>{const p=t.value/t.installments;const d=new Date(t.date+'T12:00:00');d.setMonth(d.getMonth()+t.installments-1);return <tr key={t.id}><td>{t.description}</td><td>{money(t.value)}</td><td>{t.installments}x</td><td>{money(p)}</td><td>{money(p*(t.installments-1))}</td><td>{d.toLocaleDateString('pt-BR')}</td></tr>})}</tbody></table></div></div>}

   {view==='orcamento'&&<div className="view active"><div className="panel"><h2>Orçamento</h2><table><thead><tr><th>Grupo</th><th>Categoria</th><th>Orçado</th><th>Realizado</th><th>Restante</th><th>Elasticidade</th></tr></thead><tbody>{budgets.map(b=>{const s=spent(b.category),r=b.budget-s;return <tr key={b.category}><td>{b.group}</td><td>{b.category}</td><td>{money(b.budget)}</td><td>{money(s)}</td><td className={r>=0?'green':'red'}>{money(r)}</td><td>{b.elastic}</td></tr>})}</tbody></table></div></div>}

   {view==='metas'&&<div className="view active"><div className="panel"><h2>Metas / Propósito</h2>{[['Reserva de emergência',30000,0,1000],['Viagem',8000,0,500]].map(g=><div className="row" key={g[0]}><span><b>{g[0]}</b><div className="muted">{money(g[3])}/mês · alvo {money(g[1])}</div></span><span style={{width:260}}><div className="bar"><i style={{width:(g[2]/g[1]*100)+'%'}}/></div><small>0%</small></span></div>)}</div></div>}

   {view==='projecao'&&<div className="view active"><div className="panel"><h2>Projeção simplificada</h2><table><thead><tr><th>Mês</th><th>Receitas base</th><th>Despesas base</th><th>Compromissos</th><th>Saldo projetado</th></tr></thead><tbody>{Array.from({length:Math.min(params.projectionMonths,12)},(_,i)=>{const d=new Date(2026,8+i,1);const c=i===0?future():future()/Math.max(2,12-i);return <tr key={i}><td>{d.toLocaleDateString('pt-BR',{month:'long',year:'numeric'})}</td><td>{money(income)}</td><td>{money(expense)}</td><td>{money(c)}</td><td className={income-expense-c>=0?'green':'red'}>{money(income-expense-c)}</td></tr>})}</tbody></table></div></div>}

   {view==='simulador'&&<div className="view active"><div className="panel"><h2>Simulador de compra</h2><div className="form">
    {['value','down','n','rate'].map((k,i)=><div className="field" key={k}><label>{['Valor','Entrada','Parcelas','Juros mensal %'][i]}</label><input type="number" value={sim[k]} onChange={e=>setSim({...sim,[k]:Number(e.target.value)})}/></div>)}</div>
    <div className="cards" style={{marginTop:18}}><div className="card"><div className="label">Financiado</div><div className="money">{money(simr.v)}</div></div><div className="card"><div className="label">Parcela estimada</div><div className="money">{money(simr.p)}</div></div><div className="card"><div className="label">Total</div><div className="money">{money(simr.total)}</div></div><div className="card"><div className="label">Juros</div><div className="money">{money(simr.total-sim.value)}</div></div></div></div></div>}


   {view==='config'&&<div className="view active">
    <div className="grid">
      <div className="panel">
        <h2>Parâmetros do usuário</h2>
        <p className="muted">Altere o comportamento da sua experiência sem editar código.</p>
        {[
          ['averageMonths','Meses para cálculo da média',params.averageMonths,'number'],
          ['projectionMonths','Horizonte da projeção (meses)',params.projectionMonths,'number'],
          ['minimumBalance','Saldo mínimo desejado',params.minimumBalance,'number'],
          ['budgetTolerance','Tolerância do orçamento (%)',params.budgetTolerance,'number']
        ].map(([k,label,value,type])=>
          <div className="setting" key={k}>
            <div><b>{label}</b><button className="info" onClick={()=>setHelp(parameterHelp[k])}>?</button>
            <div className="muted">Usuário · alteração imediata</div></div>
            <input type={type} value={value} onChange={e=>setParams({...params,[k]:Number(e.target.value)})}/>
          </div>
        )}
        {[
          ['showProjected','Mostrar valores projetados'],
          ['includeFuture','Considerar lançamentos futuros']
        ].map(([k,label])=>
          <div className="setting" key={k}>
            <div><b>{label}</b><button className="info" onClick={()=>setHelp(parameterHelp[k])}>?</button>
            <div className="muted">Usuário · ativar/desativar</div></div>
            <button className={'switch '+(params[k]?'on':'')} onClick={()=>setParams({...params,[k]:!params[k]})}>{params[k]?'Ativo':'Desativado'}</button>
          </div>
        )}
      </div>
      <div className="panel">
        <h2>Estrutura financeira</h2>
        <p className="muted">Classificações e regras centrais do modelo.</p>
        {[
          ['P1','Sustentação','Presente / necessidade'],
          ['P2','Previsíveis','Obrigações planejadas'],
          ['P3','Propósito','Futuro intencional'],
          ['P4','Opcionais','Presente por escolha'],
          ['P5','Quitações','Passado ainda impactando'],
          ['REP','Fluxo de Repasse','Operacional / neutro']
        ].map(x=><div className="setting" key={x[0]}><div><b>{x[0]} · {x[1]}</b><div className="muted">{x[2]}</div></div><button className="btn" onClick={()=>setHelp({title:x[0]+' · '+x[1],desc:'Grupo financeiro configurável pelo sistema. Sua função é orientar a classificação dos lançamentos e a leitura do orçamento.',example:'Uma categoria pode ser vinculada a este grupo pela tela de Categorias.',impact:'Pode afetar orçamento, dashboard, projeções e o Analista Financeiro.'})}>?</button></div>)}
      </div>
    </div>
    <div className="panel" style={{marginTop:16}}>
      <h2>Documentação e governança</h2>
      <div className="row"><span><b>Ajuda contextual</b><div className="muted">Cada parâmetro possui explicação, exemplo e impacto.</div></span><span className="tag">Ativo</span></div>
      <div className="row"><span><b>Histórico de alterações</b><div className="muted">Em uma versão persistida, registrar usuário, data, antes e depois.</div></span><span className="tag">Auditoria</span></div>
      <div className="row"><span><b>Manual operacional</b><div className="muted">Guia completo dos recursos, parâmetros e regras do produto.</div></span><span className="tag">Documentado</span></div>
    </div>
    {help&&<div className="help-overlay" onClick={()=>setHelp(null)}><div className="help-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setHelp(null)}>×</button><h2>{help.title}</h2><p>{help.desc}</p><h3>Exemplo</h3><p>{help.example}</p><h3>Impacto</h3><p>{help.impact}</p></div></div>}
   </div>

   {view==='analista'&&<div className="view active"><div className="panel chat"><h2>Analista Financeiro</h2><div className="muted">Nesta V1, o analista consulta o modelo financeiro local. A integração com um modelo de IA pode ser adicionada na próxima camada.</div>{messages.map((m,i)=><div className={'bubble '+m.who} key={i}>{m.text}</div>)}<div className="chatbar"><input value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>e.key==='Enter'&&ask()} placeholder="Ex.: quanto tenho comprometido?"/><button className="btn primary" onClick={ask}>Enviar</button></div></div></div>}
  </main>
 </div>
}
createRoot(document.getElementById('root')).render(<App/>)
