# Manual Operacional — Finanças Pessoais V1

## Objetivo
O produto organiza passado, presente e futuro financeiro. A V1 inclui Dashboard, Lançamentos, Contas, Cartões, Parcelas, Orçamento, Metas, Projeção, Simulador, Analista Financeiro e Configurações.

## Configurações
A tela **Configurações** permite alterar parâmetros do usuário sem editar código. Cada parâmetro possui `?` para ajuda contextual.

### Parâmetros do usuário
- Meses para cálculo da média
- Horizonte da projeção
- Saldo mínimo desejado
- Tolerância do orçamento
- Mostrar valores projetados
- Considerar lançamentos futuros

## Estrutura P1–P5
- P1 Sustentação
- P2 Previsíveis
- P3 Propósito
- P4 Opcionais
- P5 Quitações
- Fluxo de Repasse

## Elasticidade
- Essencial Fixo
- Otimizável
- Discricionário

## Regras centrais
1. Planejado não é realizado.
2. Compra parcelada gera compromissos futuros.
3. Pagamento de fatura não deve duplicar o consumo.
4. Transferência não é consumo.
5. Última parcela deve ser rastreável.
6. Categorias e parâmetros devem ser configuráveis.
7. Alterações relevantes devem possuir trilha de auditoria na versão persistida.

## Ajuda contextual
O padrão de documentação de cada parâmetro é: **o que faz → exemplo → impacto**.

## Evolução planejada
A próxima camada deve adicionar persistência em PostgreSQL, autenticação, API, permissões administrativas, auditoria persistente e integração do Analista Financeiro com um modelo de IA.
